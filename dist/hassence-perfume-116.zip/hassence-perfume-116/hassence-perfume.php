<?php
/*
Plugin Name: Hassence Perfume Mode
Description: Turns hassence.com into a simple perfume-only store: a perfume home page, perfume categories, and hides the vendor, Daraz and affiliate features. Keeps your colours, logo and banners.
Version: 1.0.0
Author: Hassence
*/
if (!defined('ABSPATH')) exit;
define('HSP_DIR', plugin_dir_path(__FILE__));

function hsp_cats() { return ["Women's Perfume", "Men's Perfume", 'Unisex Perfume', 'Attar & Oud', 'Body Mist', 'Gift Sets']; }
function hsp_perfume_ids() {
 $ids = [];
 foreach (hsp_cats() as $n) { $t = get_term_by('name', $n, 'product_cat'); if ($t) { $ids[] = (int) $t->term_id; foreach ((array) get_term_children($t->term_id, 'product_cat') as $c) $ids[] = (int) $c; } }
 return $ids;
}
/* Create the perfume categories and hide every other category from menus and rows */
function hsp_setup() {
 if (!taxonomy_exists('product_cat')) return;
 $keep = [];
 foreach (hsp_cats() as $n) {
  $t = term_exists($n, 'product_cat'); if (!$t) $t = wp_insert_term($n, 'product_cat');
  if (!is_wp_error($t)) { $id = (int) (is_array($t) ? $t['term_id'] : $t); $keep[] = $id; delete_term_meta($id, 'hs_hidden'); }
 }
 $def = (int) get_option('default_product_cat');
 $all = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false, 'parent' => 0]);
 if (is_array($all)) foreach ($all as $t) { if (in_array((int) $t->term_id, $keep, true) || (int) $t->term_id === $def) continue; update_term_meta($t->term_id, 'hs_hidden', '1'); }
}
register_activation_hook(__FILE__, function () { add_option('hsp_do_setup', 1); });
add_action('init', function () { if (get_option('hsp_do_setup') && taxonomy_exists('product_cat')) { hsp_setup(); delete_option('hsp_do_setup'); } }, 60);

/* Hide products that are not perfumes from the shop (and bring them back) */
function hsp_hide_others($restore = false) {
 if (!function_exists('wc_get_products')) return 0;
 $pids = hsp_perfume_ids(); $n = 0;
 foreach (wc_get_products(['limit' => -1, 'status' => 'publish', 'return' => 'ids']) as $id) {
  $p = wc_get_product($id); if (!$p) continue;
  if ($restore) { if (get_post_meta($id, '_hsp_hid', true)) { $p->set_catalog_visibility('visible'); $p->save(); delete_post_meta($id, '_hsp_hid'); $n++; } }
  elseif (!($pids && has_term($pids, 'product_cat', $id)) && $p->get_catalog_visibility() !== 'hidden') { $p->set_catalog_visibility('hidden'); $p->save(); update_post_meta($id, '_hsp_hid', 1); $n++; }
 }
 return $n;
}
add_action('admin_menu', function () {
 add_options_page('Perfume Mode', 'Perfume Mode', 'manage_options', 'hsp', function () {
  if (!current_user_can('manage_options')) return;
  $msg = '';
  if (!empty($_POST['hsp_do']) && check_admin_referer('hsp')) {
   $a = sanitize_key($_POST['hsp_do']);
   if ($a === 'cats') { hsp_setup(); $msg = 'Perfume categories created. All other categories are hidden from the menu and the home page.'; }
   if ($a === 'hide') $msg = hsp_hide_others() . ' non-perfume products were hidden from the shop.';
   if ($a === 'show') $msg = hsp_hide_others(true) . ' products were shown again.';
  }
  echo '<div class="wrap"><h1>Perfume Mode</h1>' . ($msg ? '<div class="notice notice-success"><p>' . esc_html($msg) . '</p></div>' : '');
  echo '<p>Your site now uses the simple perfume home page. These buttons tidy the rest of the shop.</p><form method="post">'; wp_nonce_field('hsp');
  echo '<p><button class="button button-primary" name="hsp_do" value="cats">1. Create perfume categories and hide all other categories</button></p>';
  echo '<p><button class="button" name="hsp_do" value="hide">2. Hide products that are not in a perfume category</button> <button class="button" name="hsp_do" value="show">Show them again</button></p></form>';
  echo '<p>Perfume categories: ' . esc_html(implode(', ', hsp_cats())) . '. Put each perfume in one of them (Products → edit → Product categories).</p></div>';
 });
});

/* Home page: simple perfume layout (uses the theme's header, banners and product cards) */
add_filter('template_include', function ($t) {
 if (is_front_page() && function_exists('hs_slides') && function_exists('hs_card') && function_exists('hs_q')) return HSP_DIR . 'templates/home.php';
 return $t;
}, 99);
/* Perfume-themed banners only when you have not added your own Banners */
add_filter('hassence_slides', function () {
 $shop = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/');
 return [
  ['linear-gradient(120deg,#111,#e0245e)', 'Find your<br>signature scent', 'Perfumes for women and men.', 'SHOP PERFUMES', $shop, '🌸'],
  ['linear-gradient(120deg,#1f1b2e,#ff6a3d)', 'Oud, attar<br>and more', 'Rich, long-lasting fragrances.', 'EXPLORE', $shop, '✨'],
 ];
});
add_action('template_redirect', function () { if (is_page('daraz')) { wp_safe_redirect(home_url('/'), 301); exit; } });

add_action('wp_head', function () { ?>
<style>
/* hide features that a perfume-only store does not need */
.sellbtn,.sellnav,.sell,.dz-strip,.dz-logo,.hsx-dz,.prog,.aff-note,footer a[href*="/daraz"],footer a[href*="/bulk-upload"]{display:none!important}
/* fix: the theme's round "+" style also hit WooCommerce's own "cart" form and table */
form.cart{position:static!important;width:100%!important;height:auto!important;min-height:0!important;border:0!important;border-radius:0!important;padding:0!important;background:transparent!important;color:inherit!important;box-shadow:none!important;display:flex!important;flex-direction:column!important;align-items:stretch!important;justify-content:flex-start!important;gap:12px;font-size:inherit!important;line-height:inherit!important;bottom:auto!important;right:auto!important;z-index:auto!important}
table.cart{position:static!important;display:table!important;width:100%!important;height:auto!important;border-radius:0!important;background:transparent!important;color:inherit!important;font-size:inherit!important;box-shadow:none!important;bottom:auto!important;right:auto!important;z-index:auto!important;padding:0!important}
@media(max-width:768px){
.woocommerce-cart-form table.cart,.woocommerce-cart-form table.cart tbody{display:block!important;width:100%!important}
.woocommerce-cart-form table.cart thead{display:none!important}
.woocommerce-cart-form table.cart tr:not(.cart_item){display:block!important}
.woocommerce-cart-form tr.cart_item{display:grid!important;grid-template-columns:78px 1fr;grid-template-areas:"thumb name" "thumb price" "thumb qty" "thumb sub";gap:6px 12px;position:relative;border:1px solid rgba(128,128,128,.35)!important;border-radius:14px;padding:12px!important;margin:0 0 12px!important;background:rgba(128,128,128,.08)}
.woocommerce-cart-form tr.cart_item td{display:block!important;border:0!important;padding:0!important;text-align:left!important;background:none!important;width:auto!important}
.woocommerce-cart-form td.product-thumbnail{grid-area:thumb}
.woocommerce-cart-form td.product-thumbnail img{width:78px!important;height:78px!important;object-fit:contain;border-radius:8px}
.woocommerce-cart-form td.product-name{grid-area:name;font-weight:800;font-size:15px}
.woocommerce-cart-form td.product-price{grid-area:price}.woocommerce-cart-form td.product-quantity{grid-area:qty}
.woocommerce-cart-form td.product-subtotal{grid-area:sub;font-weight:800}
.woocommerce-cart-form td.product-remove{position:absolute!important;top:6px;right:8px}
.woocommerce-cart-form td.product-thumbnail::before,.woocommerce-cart-form td.product-name::before,.woocommerce-cart-form td.product-remove::before{display:none!important;content:none!important}
.woocommerce-cart-form td[data-title]::before{float:none!important;font-weight:600;opacity:.7;margin-right:4px}
.woocommerce-cart-form .quantity .qty{width:90px;padding:8px;border:1px solid #666;border-radius:8px;background:#000;color:#fff;font-weight:700}
.woocommerce-cart-form td.actions{display:block!important;padding:4px 0!important;border:0!important;text-align:left!important}
.woocommerce-cart-form td.actions .coupon{display:flex;flex-direction:column;gap:8px;float:none!important;width:100%}
.woocommerce-cart-form #coupon_code{width:100%!important;background:#000!important;color:#fff!important;border:1px solid #666!important;border-radius:12px;padding:14px;font-weight:700;-webkit-text-fill-color:#fff}
.woocommerce-cart-form td.actions .button{width:100%!important;margin:8px 0 0!important;float:none!important;border-radius:30px;padding:14px}
.woocommerce-cart .cart-collaterals .cart_totals{float:none!important;width:100%!important}
.woocommerce-cart a.checkout-button{display:block;width:100%;text-align:center}
}
/* perfume home page */
.pf-h{font-size:22px;margin:28px 0 12px}
.pf-sec{display:flex;justify-content:space-between;align-items:baseline}.pf-sec .pf-h{margin-bottom:12px}.pf-all{font-weight:700;color:var(--sale,#e0245e);font-size:14px}
.pf-tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-top:16px}
.pf-tile{display:flex;flex-direction:column;align-items:center;gap:10px;padding:18px 10px;background:var(--card,#1b1b20);border:1px solid var(--bd,#2c2c34);border-radius:14px;text-align:center;transition:transform .2s,border-color .2s}
.pf-tile:hover{transform:translateY(-3px);border-color:var(--sale,#e0245e)}
.pf-ic{width:64px;height:64px;border-radius:50%;background:var(--bg,#0f0f12);display:flex;align-items:center;justify-content:center;font-size:32px;overflow:hidden}.pf-ic img{width:100%;height:100%;object-fit:cover}
.pf-tile b{font-size:14px}
.pf-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
@media(max-width:900px){.pf-grid{grid-template-columns:repeat(3,1fr)}}@media(max-width:600px){.pf-grid{grid-template-columns:repeat(2,1fr);gap:10px}}
.pf-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:10px}.pf-step{background:var(--card,#1b1b20);border:1px solid var(--bd,#2c2c34);border-radius:14px;padding:16px;text-align:center}.pf-step span{display:block;font-size:28px;margin-bottom:6px}.pf-step b{display:block}.pf-step small{color:var(--mut,#9a9aa5)}
@media(max-width:600px){.pf-steps{grid-template-columns:1fr}}
.pf-help{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin:28px 0 8px;padding:18px;border-radius:14px;background:linear-gradient(120deg,#111,#e0245e);color:#fff}
.pf-help a{background:#25D366;color:#fff!important;padding:11px 22px;border-radius:30px;font-weight:800;display:inline-flex;gap:8px;align-items:center}
</style>
<?php }, 99);
add_action('wp_footer', function () { ?>
<script>
(function(){var s=document.querySelector('.search input[type=search]');if(s)s.placeholder='Search perfumes...';
document.querySelectorAll('footer p').forEach(function(p){if(/fragrances, fashion/i.test(p.textContent))p.textContent='hassence.com - perfumes for women and men.'})})();
</script>
<?php }, 60);
