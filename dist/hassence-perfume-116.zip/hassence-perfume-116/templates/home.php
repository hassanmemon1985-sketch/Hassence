<?php
if (!defined('ABSPATH')) exit;
get_header();
$shop = wc_get_page_permalink('shop');
?>
<section class="hero"><div class="track" id="track">
<?php foreach (hs_slides() as $s) : if ($s[0] === 'img') : ?>
<a class="slide im<?php echo !empty($s[4]) ? ' hasm' : ''; ?>" href="<?php echo esc_url($s[2]); ?>" style="background-image:url('<?php echo esc_url($s[1]); ?>')<?php if (!empty($s[4])) echo ';--mob:url(\'' . esc_url($s[4]) . '\')'; ?>" aria-label="<?php echo esc_attr($s[3]); ?>"></a>
<?php continue; endif; ?>
<div class="slide" style="background:<?php echo esc_attr($s[0]); ?>"><div><h2><?php echo wp_kses_post($s[1]); ?></h2><p><?php echo wp_kses_post($s[2]); ?></p><a class="btn" href="<?php echo esc_url($s[4]); ?>"><?php echo esc_html($s[3]); ?></a></div><div class="em"><?php echo $s[5]; ?></div></div>
<?php endforeach; ?>
</div><button class="arr l" id="prev" aria-label="Previous">‹</button><button class="arr r" id="next" aria-label="Next">›</button><div class="dots" id="dots"></div></section>
</div>
<main class="wrap pf">
<?php $cats = array_slice(hs_get_cats(), 0, 6); if ($cats) : ?>
<h2 class="pf-h">Shop by type</h2>
<div class="pf-tiles"><?php foreach ($cats as $c) : $tid = get_term_meta($c->term_id, 'thumbnail_id', true); ?>
<a class="pf-tile" href="<?php echo esc_url(get_term_link($c)); ?>"><span class="pf-ic"><?php echo $tid ? wp_get_attachment_image($tid, 'medium') : hs_cat_icon($c); ?></span><b><?php echo esc_html($c->name); ?></b></a>
<?php endforeach; ?></div>
<?php endif; ?>

<?php
$shown = 0;
foreach ([['New arrivals', ['orderby' => 'date', 'order' => 'DESC']], ['Best sellers', ['orderby' => 'popularity']]] as $sec) {
 $items = hs_q(array_merge(['limit' => 8, 'visibility' => 'catalog'], $sec[1]));
 if (!$items) continue; $shown++;
 echo '<div class="pf-sec"><h2 class="pf-h">' . esc_html($sec[0]) . '</h2><a class="pf-all" href="' . esc_url($shop) . '">View all ›</a></div><div class="pf-grid">';
 foreach ($items as $p) hs_card($p);
 echo '</div>';
}
if (!$shown) echo '<div class="empty">Perfumes are coming soon.' . (current_user_can('manage_woocommerce') ? ' Add your first perfume: Products → Add New.' : '') . '</div>';
?>

<h2 class="pf-h">How to order</h2>
<div class="pf-steps">
<div class="pf-step"><span>🌸</span><b>Choose your perfume</b><small>Browse women, men and unisex fragrances</small></div>
<div class="pf-step"><span>🛒</span><b>Add it to your cart</b><small>Pick the size you like</small></div>
<div class="pf-step"><span>📦</span><b>Place your order</b><small>Cash on Delivery or Easypaisa</small></div>
</div>

<div class="pf-help"><div><b>Need help choosing a perfume?</b><br><small>Chat with us on WhatsApp.</small></div>
<?php if (function_exists('hs_wa_link')) : ?><a href="<?php echo esc_url(hs_wa_link('Hello Hassence, I need help choosing a perfume.')); ?>" target="_blank" rel="noopener"><?php echo function_exists('hs_wa_svg') ? hs_wa_svg(20) : ''; ?> Chat on WhatsApp</a><?php endif; ?></div>
</main>
<?php get_footer(); ?>
